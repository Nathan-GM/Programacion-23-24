module es.sequeros.calculadoravistanathan {
    requires javafx.controls;
    requires javafx.fxml;

    opens es.sequeros.calculadoravistanathan to javafx.fxml;
    exports es.sequeros.calculadoravistanathan;
}
