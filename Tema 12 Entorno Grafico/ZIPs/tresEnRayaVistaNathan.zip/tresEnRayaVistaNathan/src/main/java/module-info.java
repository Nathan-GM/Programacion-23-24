module es.sequeros.tresenrayavistanathan {
    requires javafx.controls;
    requires javafx.fxml;

    opens es.sequeros.tresenrayavistanathan to javafx.fxml;
    exports es.sequeros.tresenrayavistanathan;
}
