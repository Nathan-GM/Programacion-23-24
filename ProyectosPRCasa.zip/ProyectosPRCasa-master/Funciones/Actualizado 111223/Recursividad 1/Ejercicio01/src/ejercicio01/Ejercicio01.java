/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio01;

import java.util.Scanner;
/**
 *
 * @author natgonmer
 */
public class Ejercicio01 {

    /**
     * @param args the command line arguments
     */
    //Ejemplo cama y camaleon
    public static boolean esPrefijo(String a, String b) {
        boolean es = false;
        if (a.length() == 0) { //caso base 1
            return true;
        }
        if (a.length() > b.length()) { //caso base 2
            return false;
        }
        else {
            if (a.charAt(0) == b.charAt(0)) { //comprueba el primer caracter de a con el primer caracter de b
                return esPrefijo(a.substring(1, a.length()), //devuelve lo siguiente a comprobar de a
                       b.substring(1, b.length())); // devuelve lo siguiente a comprobar de b
                //en caso de A = Cama y B = Camaleon, esto devuelve al inicio con A = Ama y B = Amaleon
            }
        }
        return es;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner (System.in);
        String a;
        String b;
        System.out.println("Escribe frase A");
        a = teclado.nextLine(); // cama
        System.out.println("Escribe frase B");
        b = teclado.nextLine(); // camaleon
        if (esPrefijo(a, b)) {
            System.out.println(a + " es prefijo de " + b);
        }
        else {
            System.out.println(a + " NO es prefijo de " + b);
        }
        
    }
    
}
