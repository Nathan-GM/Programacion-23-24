/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio01;

import java.util.Scanner;
/**
 *
 * @author natgonmer
 */
public class Ejercicio01 {

    /**
     * @param args the command line arguments
     */
    
    public static double multiplica(double a, double b) {
        
        return a*b;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        System.out.println("Escribe un número");
        double numero1 = teclado.nextInt();
        System.out.println("Escribe otro número");
        double numero2 = teclado.nextInt();
        double resultado = multiplica(numero1, numero2);
        System.out.println("Resultado es " + resultado);
    }
    
}
