/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio07;

import java.util.Scanner;
/**
 *
 * @author natgonmer
 */
public class Ejercicio07 {

    /**
     * @param args the command line arguments
     */
    
    public static double perirect(double ancho, double alto) {
        double perimetro;
        perimetro = 2*(ancho + alto);
        return perimetro;
    }
    public static double arearect(double ancho, double alto) {
        double area;
        area = ancho * alto;
        return area;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        double ancho;
        double alto;
        double perimetro;
        double area;
        System.out.println("Escribe el ancho del rectangulo");
        ancho = teclado.nextDouble();
        System.out.println("Escribe el alto del rectangulo");
        alto = teclado.nextDouble();
        perimetro = perirect(ancho,alto);
        System.out.println("El perimetro es " + perimetro);
        area = arearect(ancho, alto);
        System.out.println("El area es " + area);
    }
    
}
