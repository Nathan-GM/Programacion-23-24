/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio04;

import java.util.Scanner;
/**
 *
 * @author natgonmer
 */
public class Ejercicio04 {

    /**
     * @param args the command line arguments
     */
    public static int dimeSigno(int a) {
        if (a > 0) {
            System.out.print("es positivo ");
        }
        else if (a == 0) {
            System.out.print("es igual a 0 ");
        }
        else if (a < 0) {
            System.out.print("es negativo ");
        }
        return a;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        System.out.println("Escribe un número");
        int n = teclado.nextInt();
        System.out.println("");
        System.out.print(dimeSigno(n));
        System.out.println("");
    }
    
}
