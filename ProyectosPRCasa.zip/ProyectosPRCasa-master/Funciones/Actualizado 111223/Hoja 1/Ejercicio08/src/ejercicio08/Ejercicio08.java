/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio08;

import java.util.Scanner;
/**
 *
 * @author natgonmer
 */
public class Ejercicio08 {

    /**
     * @param args the command line arguments
     */
    
    public static int suma1an(int n) {
        int suma = 0;
        for (int i = 0; i <= n; i++) {
            suma = suma + i;
        }
        return suma;
    }
    
    public static int producto1an(int n) {
        int producto = 1;
        for (int i = 1; i <= n; i++) {
            producto = producto * i;
        }
        return producto;
    }
    
    public static double intermedio1an (int n) {
        double intermedio = 0;
        intermedio = n / 2;
        return intermedio;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        int n = 0;
        int sumatorio;
        int productorio;
        double intermedio;
        System.out.println("Escribe el valor de N");
        n = teclado.nextInt();
        sumatorio = suma1an(n);
        System.out.println("El sumatorio es igual a " + sumatorio);
        productorio = producto1an(n);
        System.out.println("El productorio es igual a " + productorio);
        intermedio = intermedio1an(n);
        System.out.println("El intermedio es igual a " + intermedio);
    }
    
}
