/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio06;

import java.util.Scanner;

/**
 *
 * @author natgonmer
 */
public class Ejercicio06 {

    /**
     * @param args the command line arguments
     */
    public static double iva(double precio[]) {
        double iva = 0.21;
        double precioo = 0;
        for (int i = 0; i < precio.length; i++) {
            precioo = (precio[i] * iva) + precio[i];
        }

        return precioo;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        double[] precio = new double[5];
        double[] iapl = new double[5];
        for (int i = 0; i < precio.length; i++) {
            System.out.println("Escribe el precio del producto " + i);
            precio[i] = teclado.nextDouble();
        }
        for (int i = 0; i < iapl.length; i++) {
            iapl[i] = iva(precio);
        }
        for (int i = 0; i < iapl.length; i++) {
            System.out.println("El producto " + i + " cuesta " + iapl[i] + " tras aplicar IVA");
        }
    }

}
