/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio05;

import java.util.Scanner;

/**
 *
 * @author natgonmer
 */
public class Ejercicio05 {

    /**
     * @param args the command line arguments
     */
    public static int mikm(int millas) {
        int valor = 1852;
        int metro = millas * valor;
        return metro;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        int milla;
        int metro;
        System.out.println("Introduce la cantidad de millas marinas que tienes");
        milla = teclado.nextInt();
        metro = mikm(milla);
        System.out.println(milla + " millas marinas son " + metro + " metros");
    }

}
