/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio02;

import java.util.Scanner;

/**
 *
 * @author natgonmer
 */
public class Ejercicio02 {

    /**
     * @param args the command line arguments
     */
    public static boolean esMayorEdad(int a) {

        boolean mde = false;
        if (a >= 18) {
            mde = true;
        }
        return mde;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        System.out.println("Escribe tu edad");
        int edad = teclado.nextInt();
        if (esMayorEdad(edad) == true) {
            System.out.println("Es mayor de edad");
        } else {
            System.out.println("No es mayor de edad");
        }
    }

}
