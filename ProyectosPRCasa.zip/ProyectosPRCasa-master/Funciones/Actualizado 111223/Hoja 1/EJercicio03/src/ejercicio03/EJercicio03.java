/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio03;

import java.util.Scanner;
/**
 *
 * @author natgonmer
 */
public class EJercicio03 {

    /**
     * @param args the command line arguments
     */
    
    public static int minimo(int a, int b) {
        int menor;
        if (a > b) {
            menor = b;
        }
        else {
            menor = a;
        }
        return menor;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        System.out.println("Escribe un número");
        int n = teclado.nextInt();
        System.out.println("Escribe otro número");
        int m = teclado.nextInt();
        int res = minimo(n, m);
        System.out.println("El mínimo es " + res);
    }
    
}
