/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio06;

import java.util.Scanner;

/**
 *
 * @author natgonmer
 */
public class Ejercicio06 {

    public static boolean perteneceA(int x, int y) {
        boolean perteneceA = false;
        if (Math.pow(x, 2) + Math.pow(y, 2) <= 100) {
            perteneceA = true;
        }
        return perteneceA;
    }

    public static boolean perteneceB(int x, int y) {
        boolean perteneceB = false;
        if (Math.pow(x, 2) / 36 + Math.pow(y, 2) / 25 <= 1) {
            perteneceB = true;
        }

        return perteneceB;
    }

    public static boolean perteneceC(int x, int y) {
        boolean perteneceC = false;

        if (1 <= ((2 * x) + (4 * y))) {
            if (((2 * x) + (4 * y)) <= 10) {
                perteneceC = true;
            }
        }

        return perteneceC;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        int x = 0;
        int y = 0;
        System.out.println("Introduce el punto X");
        x = teclado.nextInt();
        System.out.println("Introduce el punto Y");
        y = teclado.nextInt();
        if (perteneceA(x, y) == true) {
            System.out.println("Los números " + x + " y " + y + " pertenecen al grupo A");
        } else {
            System.out.println("Los números " + x + " y " + y + " NO pertenecen al grupo A");
        }
        if (perteneceB(x, y) == true) {
            System.out.println("Los números " + x + " y " + y + " pertenecen al grupo B");
        } else {
            System.out.println("Los números " + x + " y " + y + " NO pertenecen al grupo B");
        }
        if (perteneceC(x, y) == true) {
            System.out.println("Los números " + x + " y " + y + " pertenecen al grupo C");
        } else {
            System.out.println("Los números " + x + " y " + y + " NO pertenecen al grupo C");
        }
        if (perteneceA(x, y) && perteneceB(x, y)) {
            System.out.println("Los números " + x + " y " + y + " pertenecen al conjunto intersección A y B");
        } else {
            System.out.println("Los números " + x + " y " + y + " NO pertenecen al conjunto intersección A y B");
        }
        if (perteneceA(x, y) && perteneceB(x, y) && perteneceC(x, y)) {
            System.out.println("Los números " + x + " y " + y + " pertenecen al conjunto intersección A y B y C");
        } else {
            System.out.println("Los números " + x + " y " + y + " NO pertenecen al conjunto intersección A y B y C");
        }
        if (perteneceA(x, y) || perteneceB(x, y)) {
            System.out.println("Los números " + x + " y " + y + " pertenecen al conjunto union A o B");
        } else {
            System.out.println("Los números " + x + " y " + y + " NO pertenecen al conjunto union A o B");
        }
        if (perteneceA(x, y) || perteneceB(x, y) || perteneceC(x, y)) {
            System.out.println("Los números " + x + " y " + y + " pertenecen al conjunto unión A o B o C");
        } else {
            System.out.println("Los números " + x + " y " + y + " NO pertenecen al conjunto unión A o B o C");
        }
    }

}
