/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio02;

/**
 *
 * @author natgonmer
 */
public class Ejercicio02 {

    /**
     * @param args the command line arguments
     */
    public static boolean esPrimo(int n) {
        boolean primo = true;

        for (int x = 2; x < n; x++) {
            if (n % x == 0) {
                primo = false;
            }
        }
        return primo;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        int primo = 0;
        int contador = 0;
        int n = 100;
        for (int i = 2; i < n; i++) {
            if (esPrimo(i)) {
                contador++;
            }

        }
        System.out.println("Entre el número " + n + " hay " + contador + " primos ");

    }

}
