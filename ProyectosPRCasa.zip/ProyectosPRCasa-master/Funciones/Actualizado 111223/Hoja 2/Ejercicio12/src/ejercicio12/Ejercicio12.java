/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio12;

/**
 *
 * @author natgonmer
 */
public class Ejercicio12 {

    /**
     * @param args the command line arguments
     */
    public static boolean nula(int [][] matriz) {
        boolean nula = true;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                if (matriz[i][j] != 0) {
                    nula = false;
                }
            }
        }
        return nula;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        int [][] matriz = new int [3][3];
        /*
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matriz [i][j] = (int) (Math.random()*10+1);
            }
        }
*/
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.printf("%4d", matriz[i][j]);
            }
            System.out.println("");
        }
        if (nula([3][3]) == true) {
            
        }
    }
    
}
