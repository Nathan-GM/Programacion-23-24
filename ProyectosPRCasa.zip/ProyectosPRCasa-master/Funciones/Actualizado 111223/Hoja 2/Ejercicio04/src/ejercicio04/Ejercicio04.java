/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio04;

/**
 *
 * @author natgonmer
 */
public class Ejercicio04 {

    public static boolean esPrimo(int n) {
        boolean primo = true;

        for (int x = 2; x < n / 2; x++) {
            if (n % x == 0) {
                primo = false;
            }
        }
        return primo;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[][] matriz = new int[5][5];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                matriz[i][j] = (int) (Math.random() * 100 + 1);
            }
        }

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.printf("%4d", matriz[i][j]);
            }
            System.out.println("");
        }
        int contador = 0;
        for (int i = 0; i < 5; i++) {
            contador = 0;
            for (int j = 0; j < 5; j++) {
                if(esPrimo(j)) {
                    contador++;
                }
            }
            System.out.println("La fila " + i + " tiene " + contador + " primos.");
        }
    }

}
