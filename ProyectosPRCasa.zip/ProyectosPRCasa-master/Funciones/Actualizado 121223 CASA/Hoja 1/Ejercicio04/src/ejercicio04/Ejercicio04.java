/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio04;

import java.util.Scanner;

/**
 *
 * @author natgonmer
 */
public class Ejercicio04 {

    /**
     * @param args the command line arguments
     */
    public static int dimeSigno(int a) {
        int sig = 0;
        if (a > 0) {
            sig = 1;
        } else if (a == 0) {
            sig = 0;
        } else if (a < 0) {
            sig = -1;
        }
        return sig;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        System.out.println("Escribe un número");
        int n = teclado.nextInt();
        System.out.println("El resultado es " + dimeSigno(n));
        System.out.println("");
        System.out.println("GUIA DE RESULTADOS");
        System.out.println("1 indica que el número es positivo");
        System.out.println("0 indica que el número es 0");
        System.out.println("-1 indica que el número es negativo");

    }

}
