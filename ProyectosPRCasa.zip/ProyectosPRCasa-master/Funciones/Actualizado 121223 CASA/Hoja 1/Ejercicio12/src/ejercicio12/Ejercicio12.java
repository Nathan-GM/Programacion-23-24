/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio12;

import java.util.Scanner;

/**
 *
 * @author Natha
 */
public class Ejercicio12 {

    /**
     * @param args the command line arguments
     */
    public static double milla(double km) {
        double millas = 0.62;
        double res = km * millas;
        /*
        double millas = 1.609344
        double res = km / millas
        lo mismo con más decimales??????????
        */
        return res;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        double kilometro = 0;
        double milla = 0;
        System.out.println("Escribe kilometros");
        kilometro = teclado.nextInt();
        milla = milla(kilometro);
        System.out.println("Eso equivale a " + milla + " millas");
    } 
}
