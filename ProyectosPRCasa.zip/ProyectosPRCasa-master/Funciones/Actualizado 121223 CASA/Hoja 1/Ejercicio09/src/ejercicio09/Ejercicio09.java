/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio09;

import java.util.Scanner;

/**
 *
 * @author Natha
 */
public class Ejercicio09 {

    /**
     * @param args the command line arguments
     */
    public static int mayor(int a, int b) {
        if (a > b) {
            return a;
        } else {
            return b;
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        int v1 = 0;
        int v2 = 0;
        int v3 = 0;
        System.out.println("Escribe el primer valor");
        v1 = teclado.nextInt();
        System.out.println("Escribe el segundo valor");
        v2 = teclado.nextInt();
        System.out.println("Escribe el tercer valor valor");
        v3 = teclado.nextInt();
        if (v1 > v3 && v2 > v3) {
            System.out.println("El numero mayor es " + mayor(v1, v2));
        } else if (v2 > v1 && v3 > v1) {
            System.out.println("El numero mayor es " + mayor(v3, v2));
        } else if (v3 > v2 && v1 > v2) {
            System.out.println("El numero mayor es " + mayor(v1, v3));
        }
    }

}
