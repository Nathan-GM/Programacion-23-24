/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio10;

import java.util.Scanner;

/**
 *
 * @author Natha
 */
public class Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static boolean Correcta(int dia, int mes) {
        boolean si = true;
        if (dia < 1 || dia > 30) {
            si = false;
        }
        if (mes < 1 || mes > 12) {
            si = false;
        }
        return si;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        int dia = 0;
        int mes = 0;
        int anyo = 0;
        System.out.println("Escribe el dia");
        dia = teclado.nextInt();
        System.out.println("Escribe el mes");
        mes = teclado.nextInt();
        System.out.println("Escribe el año");
        anyo = teclado.nextInt();
        if (Correcta(dia, mes) == true) {
            System.out.println("La fecha " + dia + "/" + mes + "/" + anyo +  " es correcta");
        } else {
            System.out.println("La fecha " + dia + "/" + mes + "/" + anyo +  " es incorrecta");
        }
    }

}
