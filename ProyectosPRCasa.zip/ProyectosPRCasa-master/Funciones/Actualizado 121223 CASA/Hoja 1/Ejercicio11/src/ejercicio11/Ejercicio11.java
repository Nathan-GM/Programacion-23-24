/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio11;

import java.util.Scanner;

/**
 *
 * @author Natha
 */
public class Ejercicio11 {

    /**
     * @param args the command line arguments
     */
    // nu preguntar luego
    public static int mult(int a) {
        int res = 0;
        for (int i = 0; i < 10; i++) {
            res = a * i;
            return res;

        }
        return res;

    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        int n = 0;
        System.out.println("Introduce un número para multiplicar");
        n = teclado.nextInt();
        System.out.println("TABLA DE MULTIPLICACIÓN DE " + n);
        for (int i = 0; i < 10; i++) {
            System.out.println(mult(n));
        }
    }

}
