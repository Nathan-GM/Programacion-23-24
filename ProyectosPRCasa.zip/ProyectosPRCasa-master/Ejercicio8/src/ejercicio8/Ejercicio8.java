/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio8;
import java.util.Scanner;
/**
 *
 * @author damtarde
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        float a;
        float b;
        float c;
        float d;
        float oa;
        float ob;
        float oc;
        float od;
        float oe;
        float of;
        float og;
        float oh;
        
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Escribe un numero para A");
        a = teclado.nextInt();
        System.out.println("Escribe un numero para B");
        b = teclado.nextInt();
        System.out.println("Escribe un numero para C");
        c = teclado.nextInt();
        System.out.println("Escribe un numero para D");
        d = teclado.nextInt();
        
        oa = (a / b) + 1;
        ob = (a + b) / (c + d);
        oc = a + (b / c);
        od = a / (b + c);
        oe = (a + b) * (c / d);
        of = (float) Math.pow(Math.pow(a+b, 2), 2);
        og = (a + b) / (1 - 4 * a);
        oh = (float) (Math.pow(a+b,2) * (a-b));
        System.out.println("El resultado de A es " + oa);
        System.out.println("El resultado de B es " + ob);
        System.out.println("El resultado de C es " + oc);
        System.out.println("El resultado de D es " + od);
        System.out.println("El resultado de E es " + oe);
        System.out.println("El resultado de F es " + of);
        System.out.println("El resultado de G es " + og);
        System.out.println("El resultado de H es " + oh);
    }      
}
