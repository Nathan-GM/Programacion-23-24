/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hormiga;

import java.util.Scanner;

/**
 *
 * @author Natha
 */
public class Hormiga {

    /**
     * @param args the command line arguments
     */
    public static void mostrar(int mapa[][], int tamano) {
        for (int i = 0; i < tamano; i++) {
            for (int j = 0; j < tamano; j++) {
                System.out.printf("%4d", mapa[i][j]);
            }
            System.out.println("");
        }
    }

    public static void terron(int mapa[][], int terrA, int terrVe, int terrVi, int tamano) {
        while (terrA > 0 || terrVe > 0 || terrVi > 0) {
            int aleatorio = (int) (Math.random() * 3+1); //creamos un selector de terron aleatorio
            int f = (int) (Math.random() * tamano);
            int c = (int) (Math.random() * tamano);
            if (terrA > 0 && aleatorio == 1) {
                mapa[f][c] = 2;
                terrA--;
            } else if (terrVi > 0 && aleatorio == 2) {
                mapa[f][c] = 3;
                terrVi--;
            } else if (terrVe > 0 && aleatorio == 3) {
                mapa[f][c] = 4;
                terrVe--;
            }
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        //Declaracion de variables

        int tamano = 0; //tamaño tablero
        int mov = 0; //movimiento normal
        int terrA = 0; //Terron Azucar
        int terrVi = 0; //Terron Vino
        int terrVe = 0; // Terron Veneno
        int hormigaF = 0; //Posicion hormiga en Filas
        int hormigaC = 0; //Posicion Hormiga en Columnas
        int movE = 0; //Movimientos Ebria

        //Damos valores a las variables
        System.out.print("Tamaño de la cuadrícula: ");
        tamano = teclado.nextInt();
        System.out.print("Movimientos de la Hormiga: ");
        mov = teclado.nextInt();
        System.out.println("Terrones de Azucar:");
        System.out.print("Normales: ");
        terrA = teclado.nextInt();
        System.out.print("Vino: ");
        terrVi = teclado.nextInt();
        System.out.print("Veneno: ");
        terrVe = teclado.nextInt();
        System.out.println("Posición de la hormiga: ");
        System.out.print("Fila: ");
        hormigaF = teclado.nextInt();
        System.out.print("Columna: ");
        hormigaC = teclado.nextInt();
        System.out.print("Movimientos si Ebria: ");
        movE = teclado.nextInt();

        //informamos de como será la distribución en el tablero
        System.out.println("En el mapa se representan así:");
        System.out.println("Hormiga: 1");
        System.out.println("Azucar: 2");
        System.out.println("Vino: 3");
        System.out.println("Veneno: 4");

        //generamos la matriz y la posición inicial de la hormiga
        int mapa[][] = new int[tamano][tamano];
        mapa[hormigaF][hormigaC] = 1;

        //mandamos a repartir los terrones por el mapa
        terron(mapa, terrA, terrVe, terrVi, tamano);

        mostrar(mapa, tamano);
    }

}
