/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elecciones;

import java.util.Scanner;

/**
 *
 * @author Natha
 */
public class Elecciones {

    /**
     * @param args the command line arguments
     */
    public static int operacion(int votos, int escanos) {
        int resultado = 0;
        resultado = (votos / (escanos + 1));
        return resultado;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        //Declaracion de variables
        int n = 0; //escaños
        int m = 0; //partidos
        int posicionE = 0;
        int posicionP = 0;
        int max = 0;
        int res = 0;
        System.out.print("¿Cuantos escaños se van a repartir? ");
        n = teclado.nextInt();
        System.out.print("¿Cuantos partidos van a participar? ");
        m = teclado.nextInt();
        //declaramos un array con la cantidad de partidos
        int[] partidos = new int[m];
        //asignamos a cada partido los votos correspondientes
        for (int i = 0; i < partidos.length; i++) {
            System.out.print("Escribe los votos del partido " + i + " ");
            partidos[i] = teclado.nextInt();
        }
        /*
        int tabla [][] = new int [escanos][partidos];
        for (int escanos = 0; escanos < n; escanos++) {
            for (int partido = 0; partido < m; partido++) {
                System.out.printf("%6d", partidos[partido]);
                if (partidos[partido] < max) {
                    max = partidos[partido];
                    posicionP = partido;
                }

            }
            res = operacion(max ,escanos);
            max = 0;
            partidos[posicionP+1] = res;
            System.out.println("");
        }
        */
        for (int j = 0  ; j <= m; j++) {
            for (int i = 0; i < partidos.length; i++) {
                System.out.printf("%6d", partidos[i]);
                if (partidos[i] < max) {
                    max = partidos[i];
                    posicionP = i;
                }
            }
            System.out.println("");
            res = operacion(max, j);
            partidos[posicionP+1] = res;
        }
        System.out.println("");
    }
         
    
}
