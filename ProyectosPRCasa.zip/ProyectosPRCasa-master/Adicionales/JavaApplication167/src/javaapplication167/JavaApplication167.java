/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication167;

import java.util.Scanner;

/**
 *
 * @author Natha
 */
public class JavaApplication167 {

    /**
     * @param args the command line arguments
     */
   //Creamos la variable inundadas fuera para que todas las funciones puedan utilizarla sin ningún problema.
    static int inundadas = 1;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Creamos las variables de ancho y alto para que el usuario los introduzca por teclado.
        System.out.println("Introduce un ancho, entre 1 a 100.");
        int ancho = sc.nextInt();
        System.out.println("Introduce un alto, entre 1 a 100 y que este sea impar.");
        int alto = sc.nextInt();

        //Le damos "reglas" a las variables para en caso de no cumplir que sea impar o que sea superior al número indicado el programa de error.
        if (ancho > 100 || ancho < 1) {
            System.out.println("Es un número no aceptado, intenta de nuevo");
        }
        if (alto > 100 || alto < 1 || alto % 2 == 0) {
            System.out.println("Es un número no aceptado, intenta de nuevo");
        }

        //Creamos el array superficie para poder crear el tablero.
        int superficie[][] = new int[ancho][alto];
        for (int i = 0; i < ancho; i++) {
            for (int j = 0; j < alto; j++) {
                //Creamos números aleatorios del 0 al 10 para cada posición del tablero.
                superficie[i][j] = (int) (0 + Math.random() * 10);
                //Indicamos que la fila central de la primera columna del tablero siempre sea 0.
                superficie[alto / 2][0] = 0;
                System.out.print(" " + superficie[i][j] + " ");
            }
            System.out.println("");
        }

        //Creamos la variable "agua", la cual actuará de contador para subir el nivel del agua.
        int agua = 1;

        //Usamos el array de nuevo para poder ver las posiciones del tablero y si son inundadas.
        superficie[alto / 2][0] = 11;
        while (inundadas <= (ancho * alto) / 2 && agua <= 10) {
            for (int i = 0; i < ancho; i++) {
                for (int j = 0; j < alto; j++) {
                    //Centro
                    if (superficie[i][j] == 11) {
                        //Izquierda
                        if (j - 1 >= 0) {
                            resultado(agua, superficie, i, j - 1);
                        }
                        //Derecha
                        if (j + 1 < alto) {
                            resultado(agua, superficie, i, j + 1);
                        }
                        //Arriba
                        if (i - 1 >= 0) {
                            resultado(agua, superficie, i - 1, j);
                        }
                        //Abajo
                        if (i + 1 < ancho) {
                            resultado(agua, superficie, i + 1, j);
                        }
                    }
                }
            }
            //Aumentamos el contador de "agua" para revisar el siguiente nivel.
            agua++;
        }
        //Mostramos al usuario el número de casillas inundadas y el nivel del agua.
        System.out.println("Las casillas inundadas son " + inundadas);
        System.out.println("El nivel del agua es " + agua);
        for (int i = 0; i < ancho; i++) {
            for (int j = 0; j < alto; j++) {
                System.out.printf("%4d", superficie[i][j]);
            }
            System.out.println("");
        }
    }

    //Creamos otra función para poder indicar todas las posiciones inundadas.
    public static void resultado(int agua, int superficie[][], int i, int j) {
        if (superficie[i][j] <= agua) {
            superficie[i][j] = 11;
            inundadas++;
        }
    }
}