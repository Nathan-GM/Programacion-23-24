/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arbolenarbol;

import java.util.Scanner;

/**
 *
 * @author Natha
 */
public class ArbolenArbol {

    /**
     * @param args the command line arguments
     */
    public static void mapa(int tablero[][], int f, int c) {
        //asignamos los arboles fijos
        tablero[0][0] = 'A';
        tablero[(f - 1)][(c - 1)] = 'A';
        
        //mostramos el tablero
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                System.out.printf("%4d",tablero[i][j]);
            }
            System.out.println("");
        }
    }
    
    public static int salto(int tablero[][], int f, int c, int jump) {
        return c;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        //declaracion de variables
        int f = 0; //filas
        int c = 0; //columnas
        int s = 0; //distancia máxima de salto
        int a = 0; //cantidad inicial de arboles
        int cf = 0; //coordenadas filas
        int cc = 0; //coordenadas arbol
        //2 de ellos fijos en 0,0 y f,c
        
        //Se le dan valores a F y a C
        System.out.print("Indica la cantidad de filas: ");
        f = teclado.nextInt();
        System.out.print("Indica la cantidad de columnas: ");
        c = teclado.nextInt();
        
        //Con dichos valores creamos la matriz tablero
        int[][] tablero = new int[f][c];
        
        //indicamos la distancia de salto y la cantidad de arboles que habrá
        System.out.print("Indica la distancia máxima de salto: ");
        s = teclado.nextInt();
        System.out.print("Indica la cantidad de árboles (habrá 2 fijos): ");
        a = teclado.nextInt();
        //Para la cantidad de arboles indicados le daremos una cordenada de filas y de columnas
        for (int i = 0; i < a; i++) {
            System.out.println("Indica las coordenadas para el arbol " + i);
            System.out.print("Filas: ");
            cf = teclado.nextInt();
            System.out.print("Columnas: ");
            cc = teclado.nextInt();
            tablero[cf][cc] = 'A';
            cf = 0;
            cc = 0;
        }
        
        mapa(tablero, f, c);
    }

}
