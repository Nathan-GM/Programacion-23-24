/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nilo;

import java.util.Scanner;

/**
 *
 * @author Natha
 */
public class Nilo {

    /**
     * @param args the command line arguments
     */
    public static void mostrar(int[][] superficie, int filas, int columnas) {
        for (int i = 0; i < columnas; i++) {
            for (int j = 0; j < filas; j++) {
                System.out.printf("%4d", superficie[i][j]);
            }
            System.out.println("");
        }
    }

    /*
    public static int comp(int [][] sup, int iniciof, int iniciop) {
        int res = 0;
        if (sup[(iniciof + 1)[iniciop] <= 0]) {
            return res;
        }
    }
*/
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        int p = 0; //ancho
        int f = 0; //alto
        int n0 = 0;
        int crecida = 0; //crecida necesaria para inundar la mitad
        int anegadas = 0; //casillas anegadas
        do {
            System.out.println("Escribe el ancho del terreno (entre 1 y 100)");
            p = teclado.nextInt();
            System.out.println("Escribe el alto del terreno, debe ser impar (entre 1 y 100)");
            f = teclado.nextInt();
            if (p <= 1 || p >= 100 || f <= 1 || f >= 100 || f % 2 == 0) {
                System.out.println("Los números introducidos no son validos");
            }
        } while (p <= 1 || p >= 100 || f <= 1 || f >= 100 || f % 2 == 0);
        int[][] superficie = new int[f][p];

        for (int filas = 0; filas < f; filas++) {
            for (int columnas = 0; columnas < p; columnas++) {
                superficie[filas][columnas] = (int) (Math.random() * 10);
            }
        }
        n0 = f / 2;
        superficie[n0][0] = 0;
        int fi = n0;
        int pi = 0;
        mostrar(superficie, p, f);
        //mientras que las casillas anegadas sean menor a la mitad hará las comprobaciones
        while (anegadas <= (f*p) / 2) {
            for (int alto = 0; alto < f; alto++) {
                for (int ancho = 0; ancho < p; ancho++) {
                    if (superficie[alto][ancho] == 20) {
                        
                }
            }
            }
        }
    }
}
