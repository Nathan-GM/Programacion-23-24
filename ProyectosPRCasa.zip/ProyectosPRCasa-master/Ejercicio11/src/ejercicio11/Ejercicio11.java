package ejercicio11;
import java.util.Scanner;
public class Ejercicio11 {
    public static void main(String[] args) {
        float a;
        float b;
        float c;
        float d;
        float distancia;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Escribe los numeros correspondientes a A, B, C y D.");
        a = teclado.nextInt();
        b = teclado.nextInt();
        c = teclado.nextInt();
        d = teclado.nextInt();
        distancia = (float) Math.sqrt((Math.pow(c - a, 2)) + Math.pow(d - b , 2));
        System.out.println("La distancia entre P y Q es de" + distancia);
    }
}